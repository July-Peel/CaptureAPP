function setProgressDemo1(val) {
  document.getElementById("app-progress-demo-1").style.width = `${val}%`;
  document.getElementById("app-progress-demo-1_text").innerHTML = `${val}%`;
}